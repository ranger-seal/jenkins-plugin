/*
 * The MIT License
 *
 * Copyright (c) 2014, Matthew DeTullio
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.github.mjdetullio.jenkins.plugins.multibranch;

import edu.umd.cs.findbugs.annotations.NonNull;
import java.io.IOException;
import java.util.Objects;
import org.kohsuke.stapler.StaplerRequest2;
import org.kohsuke.stapler.StaplerResponse2;
import org.kohsuke.stapler.StaplerResponse2Wrapper;

/**
 * Prevents the internal template project from committing a redirect after it
 * finishes handling the shared configuration request in
 * {@link hudson.model.AbstractProject#doConfigSubmit(StaplerRequest2, StaplerResponse2)}.
 *
 * <p>The wrapper delegates every response operation except redirects. This lets
 * the parent multi-branch project's configuration submission control the final
 * browser response.</p>
 *
 * @author Matthew DeTullio
 */
public final class TemplateStaplerResponseWrapper extends StaplerResponse2Wrapper {

    /**
     * Creates a response wrapper around the response used to configure the
     * multi-branch project.
     *
     * @param response response to wrap
     */
    TemplateStaplerResponseWrapper(@NonNull StaplerResponse2 response) {
        super(Objects.requireNonNull(response, "response must not be null"));
    }

    /**
     * Intentionally ignores a standard redirect requested by the template job.
     *
     * @param url ignored redirect URL
     * @throws IOException declared by the response API; never thrown here
     */
    @Override
    public void sendRedirect(@NonNull String url) throws IOException {
        // Intentionally ignored.
    }

    /**
     * Intentionally ignores a redirect with an explicit HTTP status code.
     *
     * @param statusCode ignored HTTP status code
     * @param url ignored redirect URL
     * @throws IOException declared by the response API; never thrown here
     */
    @Override
    public void sendRedirect(int statusCode, @NonNull String url) throws IOException {
        // Intentionally ignored.
    }

    /**
     * Intentionally ignores Stapler's URL-encoding redirect helper.
     *
     * @param url ignored redirect URL
     * @throws IOException declared by the response API; never thrown here
     */
    @Override
    public void sendRedirect2(@NonNull String url) throws IOException {
        // Intentionally ignored.
    }
}
