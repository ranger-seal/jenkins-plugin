/*
 * The MIT License
 *
 * Copyright (c) 2016, Matthew DeTullio
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.github.mjdetullio.jenkins.plugins.multibranch;

import edu.umd.cs.findbugs.annotations.NonNull;
import hudson.BulkChange;
import hudson.XmlFile;
import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.Item;
import hudson.model.Items;
import hudson.model.Saveable;
import hudson.model.TopLevelItem;
import hudson.util.AtomicFileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import jenkins.branch.Branch;
import jenkins.branch.BranchProjectFactory;
import jenkins.branch.BranchProperty;
import jenkins.model.Jenkins;
import jenkins.scm.api.SCMHead;
import jenkins.security.NotReallyRoleSensitiveCallable;
import jenkins.util.xml.XMLUtils;
import org.xml.sax.SAXException;

/**
 * A branch project factory that copies configuration from the hidden template
 * project and then restores branch-specific state managed by Branch API.
 *
 * @param <P> branch project type
 * @param <B> branch build type
 * @author Matthew DeTullio
 */
public abstract class TemplateDrivenBranchProjectFactory<
                P extends AbstractProject<P, B> & TopLevelItem,
                B extends AbstractBuild<P, B>>
        extends BranchProjectFactory<P, B> {

    @NonNull
    @Override
    public Branch getBranch(@NonNull P project) {
        BranchProjectProperty<P, B> property =
                project.getProperty(BranchProjectProperty.class);

        /*
         * A user can configure a branch project directly and remove its
         * BranchProjectProperty. Recreate a temporary branch so indexing can
         * subsequently restore the authoritative branch metadata.
         */
        if (property == null) {
            Branch branch = new Branch(
                    "unknown",
                    new SCMHead(project.getDisplayName()),
                    project.getScm(),
                    Collections.<BranchProperty>emptyList());
            setBranch(project, branch);
            return branch;
        }
        return property.getBranch();
    }

    @NonNull
    @Override
    public P setBranch(@NonNull P project, @NonNull Branch branch) {
        BranchProjectProperty<P, B> property =
                project.getProperty(BranchProjectProperty.class);
        BulkChange bulkChange = new BulkChange(project);
        boolean committed = false;
        try {
            if (property == null) {
                project.addProperty(new BranchProjectProperty<>(branch));
            } else {
                property.setBranch(branch);
            }
            project.setScm(branch.getScm());
            bulkChange.commit();
            committed = true;
        } catch (IOException e) {
            throw new IllegalStateException(
                    "Unable to set branch metadata on " + project.getFullName(), e);
        } finally {
            if (!committed) {
                bulkChange.abort();
            }
        }
        return project;
    }

    /**
     * Decorates a branch project by applying the hidden template configuration,
     * restoring branch-managed fields, and saving the resulting configuration.
     *
     * @param project project to decorate
     * @return decorated project
     */
    @Override
    public P decorate(@NonNull P project) {
        if (!isProject(project)) {
            return project;
        }
        if (!(getOwner() instanceof TemplateDrivenMultiBranchProject<?, ?>)) {
            throw new IllegalStateException(String.format(
                    "%s can only be used with %s.",
                    TemplateDrivenBranchProjectFactory.class.getSimpleName(),
                    TemplateDrivenMultiBranchProject.class.getSimpleName()));
        }

        @SuppressWarnings("unchecked")
        TemplateDrivenMultiBranchProject<P, B> owner =
                (TemplateDrivenMultiBranchProject<P, B>) getOwner();

        Branch branch = getBranch(project);
        String displayName = project.getDisplayNameOrNull();
        boolean wasDisabled = project.isDisabled();
        BulkChange bulkChange = new BulkChange(project);
        boolean committed = false;

        try {
            updateByXml(
                    project,
                    new StreamSource(owner.getTemplate().getConfigFile().readRaw()));

            // Restore fields managed by this plugin and Branch API.
            setBranch(project, branch);
            project.setDisplayName(displayName);
            project.setScm(branch.getScm());

            // Workarounds retained from JENKINS-21017.
            project.setBuildDiscarder(owner.getTemplate().getBuildDiscarder());
            project.setCustomWorkspace(owner.getTemplate().getCustomWorkspace());

            if (!wasDisabled) {
                project.enable();
            }

            project = super.decorate(project);
            bulkChange.commit();
            committed = true;
            return project;
        } catch (IOException e) {
            throw new IllegalStateException(
                    "Unable to update branch project " + project.getFullName(), e);
        } finally {
            if (!committed) {
                bulkChange.abort();
            }
        }
    }

    /**
     * Mirrors {@link hudson.model.AbstractItem#updateByXml(Source)} without
     * firing {@link hudson.model.listeners.SaveableListener#fireOnChange(Saveable, XmlFile)}.
     * Avoiding that event prevents the template synchronization listener from
     * recursively redecorating the same branch project.
     *
     * @param project project to update
     * @param source XML configuration source
     * @throws IOException if the configuration cannot be persisted or reloaded
     */
    private void updateByXml(@NonNull P project, @NonNull Source source) throws IOException {
        project.checkPermission(Item.CONFIGURE);

        String projectName = project.getName();
        XmlFile configXmlFile = project.getConfigFile();
        AtomicFileWriter writer =
                new AtomicFileWriter(configXmlFile.getFile().toPath(), StandardCharsets.UTF_8);
        boolean committed = false;

        try {
            try {
                XMLUtils.safeTransform(source, new StreamResult(writer));
                writer.close();
            } catch (SAXException | TransformerException e) {
                throw new IOException("Failed to persist config.xml", e);
            }

            Object unmarshalled = new XmlFile(
                            Items.XSTREAM2, writer.getTemporaryPath().toFile())
                    .unmarshal(project);
            if (unmarshalled != project) {
                throw new IOException("Expected " + project.getClass().getName()
                        + " but got " + unmarshalled.getClass().getName());
            }

            Items.whileUpdatingByXml(new NotReallyRoleSensitiveCallable<Void, IOException>() {
                private static final long serialVersionUID = 1L;

                @Override
                public Void call() throws IOException {
                    project.onLoad(project.getParent(), projectName);
                    return null;
                }
            });

            Jenkins.get().rebuildDependencyGraphAsync();
            writer.commit();
            committed = true;
        } finally {
            if (!committed) {
                writer.abort();
            }
        }
    }
}
