/*
 * The MIT License
 *
 * Copyright (c) 2014, Matthew DeTullio
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.github.mjdetullio.jenkins.plugins.multibranch;

import edu.umd.cs.findbugs.annotations.NonNull;
import hudson.DescriptorExtensionList;
import hudson.scm.NullSCM;
import hudson.triggers.Trigger;
import hudson.triggers.TriggerDescriptor;
import jakarta.servlet.ServletException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Objects;
import net.sf.json.JSONObject;
import org.kohsuke.stapler.StaplerRequest2;

/**
 * Prevents configuration values belonging to a
 * {@link TemplateDrivenMultiBranchProject} from bleeding into the internal
 * template job when the same submitted form is passed to the template project's
 * configuration submission method.
 *
 * <p>This implementation deliberately wraps the public {@link StaplerRequest2}
 * interface. It does not cast to Stapler's internal {@code RequestImpl}, because
 * modern Jenkins versions may supply a wrapped request implementation.</p>
 *
 * @author Matthew DeTullio
 */
public final class TemplateStaplerRequestWrapper {

    private static final String PROJECT_FACTORY = "projectFactory";

    private TemplateStaplerRequestWrapper() {
        // Utility class.
    }

    /**
     * Wraps the supplied request while overriding only the values required when
     * the multi-branch configuration is applied to the internal template job.
     *
     * @param request request submitted for the multi-branch project
     * @return wrapped request suitable for the template project
     */
    public static StaplerRequest2 wrap(@NonNull StaplerRequest2 request) {
        Objects.requireNonNull(request, "request must not be null");

        InvocationHandler handler = (proxy, method, args) -> {
            if (method.getDeclaringClass() == Object.class) {
                return invokeObjectMethod(proxy, method, args, request);
            }

            String methodName = method.getName();
            if ("getParameter".equals(methodName)
                    && args != null
                    && args.length == 1
                    && args[0] instanceof String parameterName) {
                return getParameter(request, parameterName);
            }

            if ("getSubmittedForm".equals(methodName)
                    && (args == null || args.length == 0)) {
                return getSubmittedForm(request);
            }

            return invokeDelegate(request, method, args);
        };

        return (StaplerRequest2) Proxy.newProxyInstance(
                StaplerRequest2.class.getClassLoader(),
                new Class<?>[] {StaplerRequest2.class},
                handler);
    }

    private static Object invokeObjectMethod(
            Object proxy, Method method, Object[] args, StaplerRequest2 request) {
        return switch (method.getName()) {
            case "equals" -> proxy == (args == null ? null : args[0]);
            case "hashCode" -> System.identityHashCode(proxy);
            case "toString" -> TemplateStaplerRequestWrapper.class.getSimpleName()
                    + "[delegate=" + request + "]";
            default -> throw new UnsupportedOperationException(
                    "Unsupported Object method: " + method.getName());
        };
    }

    private static Object invokeDelegate(
            StaplerRequest2 request, Method method, Object[] args) throws Throwable {
        try {
            return method.invoke(request, args);
        } catch (InvocationTargetException e) {
            throw e.getCause();
        }
    }

    /**
     * Returns sanitized parameter values required when updating the internal
     * template project.
     *
     * @param request original request
     * @param name parameter name
     * @return sanitized or delegated parameter value
     */
    private static String getParameter(StaplerRequest2 request, String name) {
        if ("name".equals(name) || "description".equals(name)) {
            return null;
        }
        if ("disable".equals(name)) {
            return "";
        }

        DescriptorExtensionList<Trigger<?>, TriggerDescriptor> triggerDescriptors = Trigger.all();
        JSONObject submittedForm = null;
        for (TriggerDescriptor triggerDescriptor : triggerDescriptors) {
            String safeName = triggerDescriptor.getJsonSafeClassName();
            if (name.equals(safeName)) {
                if (submittedForm == null) {
                    submittedForm = getSubmittedFormUnchecked(request);
                }
                if (isMissingOrNull(submittedForm, safeName)) {
                    return null;
                }
            }
        }

        return request.getParameter(name);
    }

    private static JSONObject getSubmittedFormUnchecked(StaplerRequest2 request) {
        try {
            return getSubmittedForm(request);
        } catch (ServletException e) {
            throw new IllegalStateException("Unable to read submitted template configuration", e);
        }
    }

    private static boolean isMissingOrNull(JSONObject form, String name) {
        if (!form.containsKey(name)) {
            return true;
        }
        Object value = form.get(name);
        return value == null || (value instanceof JSONObject json && json.isNullObject());
    }

    /**
     * Returns a defensive copy of the project-factory portion of the submitted
     * form with a dummy {@link NullSCM} definition. The dummy SCM is required
     * because the template configuration page does not contain normal SCM form
     * elements.
     *
     * @param request original request
     * @return sanitized project-factory JSON
     * @throws ServletException if the submitted form cannot be read
     */
    private static JSONObject getSubmittedForm(StaplerRequest2 request)
            throws ServletException {
        JSONObject submittedForm = request.getSubmittedForm();
        JSONObject projectFactory = new JSONObject();

        if (submittedForm != null && submittedForm.containsKey(PROJECT_FACTORY)) {
            Object value = submittedForm.get(PROJECT_FACTORY);
            if (value instanceof JSONObject json && !json.isNullObject()) {
                projectFactory = JSONObject.fromObject(json);
            }
        }

        JSONObject scm = new JSONObject();
        scm.put("value", "0");
        scm.put("stapler-class", NullSCM.class.getName());
        scm.put("$class", NullSCM.class.getName());
        projectFactory.put("scm", scm);

        return projectFactory;
    }
}
